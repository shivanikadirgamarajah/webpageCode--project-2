
function openNav() {
  document.getElementById("mySidebar").style.width = "250px";
document.getElementById("main").style.marginLeft = "250px";
    const footer= document.querySelector('.footer');
    footer.style.left="250px";
    footer.style.width="calc(100%-250px)";
   document.getElementById("openbtn").style.display = "none";

    document.body.classList.add("nav-open");
    document.getElementById("right").style.marginRight="125px";
    document.getElementById("right").style.marginTop="20px";
}


function closeNav() {
    document.getElementById("right").style.marginRight="0px";
    document.getElementById("right").style.marginTop="0px";
  document.getElementById("mySidebar").style.width = "0";
  document.getElementById("main").style.marginLeft = "0";
     const footer = document.querySelector('.footer');
    footer.style.left="0";
    document.getElementById("openbtn").style.display = "inline-block";

    footer.style.width="100%";
}